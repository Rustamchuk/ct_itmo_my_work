#include "return.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <zlib.h>

typedef unsigned char byte;
typedef unsigned long ulong;

typedef struct
{
	char *type;
	byte *data;
	byte *filter;
	int colour;
	int streams;
	size_t height;
	size_t width;
} PNM;

typedef struct
{
	int code;
	char *message;
} ERROR;

int isPNG(FILE *filePNG);
int getChunkSize(FILE *filePNG, ERROR *error);
void getChunkName(FILE *filePNG, byte *name, ERROR *error);
int isChunk(const byte *word, const char *name);
void readChunk(FILE *filePNG, byte *data, ulong size, ERROR *error);
void parseIHDR(PNM *pnm, byte *options, ERROR *error);
void parsePLTE(PNM *pnm, const byte *library, ulong size);
void decompressIDAT(PNM *pnm, byte *dataIDAT, ulong sizeIDAT, ERROR *error);
void decompressPLTE(PNM *pnm, const byte *dataPLTE, ERROR *error);
void filter(PNM *pnm, ERROR *error);
void filterSub(PNM *pnm, ulong start);
void filterUp(PNM *pnm, ulong start);
void filterAverage(PNM *pnm, ulong start);
void filterPaeth(PNM *pnm, ulong start);

int main(int argc, char **argv)
{
	ERROR error = { SUCCESS, "" };

	if (argc != 3)
	{
		error.code = ERROR_PARAMETER_INVALID;
		error.message = "Wrong number args";
		goto finish;
	}

	FILE *filePNG = fopen(argv[1], "rb");
	if (filePNG == NULL)
	{
		error.code = ERROR_CANNOT_OPEN_FILE;
		error.message = "Cannot open PNG file";
		goto finish;
	}
	if (!isPNG(filePNG))
	{
		fclose(filePNG);
		error.code = ERROR_DATA_INVALID;
		error.message = "Was open not PNG file";
		goto finish;
	}

	ulong size = getChunkSize(filePNG, &error);
	if (error.code != SUCCESS)
	{
		goto finish;
	}

	byte name[4];
	getChunkName(filePNG, name, &error);
	if (error.code != SUCCESS)
	{
		goto finish;
	}
	if (!isChunk(name, "IHDR"))
	{
		error.code = ERROR_DATA_INVALID;
		error.message = "Not expected chunk, expected IHDR";
		goto finish;
	}
	PNM pnm;

	if (size != 13)
	{
		error.code = ERROR_DATA_INVALID;
		error.message = "Wrong number of size IHDR";
		goto finish;
	}
	byte options[13];
	readChunk(filePNG, options, size, &error);
	if (error.code != SUCCESS)
	{
		goto finish;
	}
	parseIHDR(&pnm, options, &error);

	byte *libraryPLTE;
	byte *compressData;
	int PLTE = 0;
	int IDAT = 0;
	ulong lastSize;
	while (!isChunk(name, "IEND"))
	{
		size = getChunkSize(filePNG, &error);
		if (error.code != SUCCESS)
		{
			goto finish;
		}

		getChunkName(filePNG, name, &error);
		if (error.code != SUCCESS)
		{
			goto finish;
		}

		if (isChunk(name, "PLTE"))
		{
			if (pnm.colour == 0 || size % 3 != 0 || size > 256 * 3 || PLTE != 0)
			{
				error.code = ERROR_DATA_INVALID;
				error.message = "Not expected PLTE";
				goto finish;
			}
			PLTE++;
			libraryPLTE = (byte *)malloc(size * sizeof(byte));
			if (libraryPLTE == NULL)
			{
				error.code = ERROR_OUT_OF_MEMORY;
				error.message = "Cannot get memory for array libraryPLTE";
				goto finish;
			}
			readChunk(filePNG, libraryPLTE, size, &error);
			if (error.code != SUCCESS)
			{
				goto finish;
			}
			parsePLTE(&pnm, libraryPLTE, size);
			if (error.code != SUCCESS)
			{
				goto finish;
			}
		}
		else if (isChunk(name, "IDAT"))
		{
			if (pnm.colour == 3 && PLTE == 0)
			{
				error.code = ERROR_DATA_INVALID;
				error.message = "Expected PLTE";
				goto finish;
			}
			IDAT++;
			if (IDAT == 1)
			{
				compressData = (byte *)malloc(size * sizeof(byte));
				if (compressData == NULL)
				{
					error.code = ERROR_DATA_INVALID;
					error.message = "Cannot get memory for array ComressData";
					goto finish;
				}
				readChunk(filePNG, compressData, size, &error);
				lastSize = size;
			}
			else
			{
				compressData = (byte *)realloc(compressData, (lastSize + size) * sizeof(byte));
				if (compressData == NULL)
				{
					error.code = ERROR_DATA_INVALID;
					error.message = "Cannot get memory for array ComressData";
					goto finish;
				}
				byte *data = (byte *)malloc(size * sizeof(byte));
				if (data == NULL)
				{
					error.code = ERROR_DATA_INVALID;
					error.message = "Cannot get memory for array data";
					goto finish;
				}
				readChunk(filePNG, data, size, &error);
				for (int i = 0; i < size; i++)
				{
					compressData[lastSize + i] = data[i];
				}
				lastSize += size;
			}
			if (error.code != SUCCESS)
			{
				goto finish;
			}
		}
		else if (fseek(filePNG, size * sizeof(byte), 1))
		{
			error.code = ERROR_DATA_INVALID;
			error.message = "Don't expected end of file";
			goto finish;
		}
		else if (fseek(filePNG, 4, 1))
		{
			error.code = ERROR_DATA_INVALID;
			error.message = "Don't expected end of file";
			goto finish;
		}
	}
	fclose(filePNG);
	if (IDAT == 0)
	{
		error.code = ERROR_DATA_INVALID;
		error.message = "There's no IDAT";
		goto finish;
	}
	decompressIDAT(&pnm, compressData, size, &error);
	if (error.code != SUCCESS)
	{
		goto finish;
	}
	free(compressData);

	filter(&pnm, &error);
	if (error.code != SUCCESS)
	{
		goto finish;
	}

	if (PLTE != 0)
	{
		decompressPLTE(&pnm, libraryPLTE, &error);
		free(libraryPLTE);
		if (error.code != SUCCESS)
		{
			goto finish;
		}
	}

	FILE *out = fopen(argv[2], "wb");
	if (out == NULL)
	{
		error.code = ERROR_CANNOT_OPEN_FILE;
		error.message = "Cannot open PNM file";
		goto finish;
	}
	fprintf(out, "%s\n%i %i\n%i\n", pnm.type, pnm.width, pnm.height, 255);
	if (fwrite(pnm.data, sizeof(int), pnm.width * pnm.height * pnm.streams, out) != pnm.width * pnm.height * pnm.streams)
	{
		error.code = ERROR_DATA_INVALID;
		error.message = "Error: Failed to write all elements to file.";
		goto finish;
	}
	fclose(out);
	free(pnm.data);

finish:
	if (error.code != SUCCESS)
	{
		printf("%s", error.message);
	}
	return error.code;
}

int isPNG(FILE *filePNG)
{
	const byte signature[] = { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A };
	byte actualSignature[8];
	if (fread(actualSignature, sizeof(byte), 8, filePNG) != 8)
	{
		return 0;
	}
	for (int i = 0; i < 8; i++)
	{
		if (signature[i] != actualSignature[i])
		{
			return 0;
		}
	}
	return 1;
}

int byteToInt(const byte *size, int start, int finish)
{
	int move = 1;
	int res = 0;
	for (int i = finish - 1; i >= start; i--)
	{
		res += ((int)size[i]) * move;
		move *= 256;
	}
	return res;
}

int getChunkSize(FILE *filePNG, ERROR *error)
{
	byte size[4];
	ulong n = fread(size, sizeof(byte), 4, filePNG);
	if (n != 4)
	{
		error->code = ERROR_DATA_INVALID;
		error->message = "Don't get 4 size bytes";
		return 0;
	}
	return byteToInt(size, 0, 4);
}

void getChunkName(FILE *filePNG, byte *name, ERROR *error)
{
	if (fread(name, sizeof(byte), 4, filePNG) != 4)
	{
		error->code = ERROR_DATA_INVALID;
		error->message = "Don't get 4 name bytes";
	}
}

void parseIHDR(PNM *pnm, byte *options, ERROR *error)
{
	pnm->width = byteToInt(options, 0, 4);
	pnm->height = byteToInt(options, 4, 8);
	if (options[8] != 0x08)
	{
		error->code = ERROR_DATA_INVALID;
		error->message = "Don't get color depth 0x08";
		return;
	}
	pnm->colour = options[9];
	if (pnm->colour == 0)
	{
		pnm->type = "P5";
		pnm->streams = 1;
	}
	else if (pnm->colour == 2)
	{
		pnm->type = "P6";
		pnm->streams = 3;
	}
	else
	{
		pnm->type = "P6";
		pnm->streams = 1;
	}
}

void parsePLTE(PNM *pnm, const byte *library, ulong size)
{
	for (int i = 0; i < size / 3; i++)
	{
		if (library[i * 3] != library[i * 3 + 1] || library[i * 3] != library[i * 3 + 2] || library[i * 3 + 1] != library[i * 3 + 2])
		{
			return;
		}
	}
	pnm->type = "P5";
}

void readChunk(FILE *filePNG, byte *data, ulong size, ERROR *error)
{
	if (fread(data, sizeof(byte), size, filePNG) != size)
	{
		error->code = ERROR_DATA_INVALID;
		error->message = "Don't get expected number of bytes";
		return;
	}
	fseek(filePNG, sizeof(byte) * 4, 1);	// control sum
}

void decompressIDAT(PNM *pnm, byte *dataIDAT, const ulong sizeIDAT, ERROR *error)
{
	ulong size = pnm->height * pnm->width * pnm->streams + pnm->height;

	pnm->data = (byte *)malloc(pnm->height * pnm->width * pnm->streams * sizeof(byte));
	pnm->filter = (byte *)malloc(pnm->height * sizeof(byte));
	byte *allData = (byte *)malloc(size * sizeof(byte));
	if (pnm->data == NULL || pnm->filter == NULL || allData == NULL)
	{
		error->code = ERROR_DATA_INVALID;
		error->message = "Cannot get size for array in decompressIDAT";
		return;
	}
	switch (uncompress(allData, &size, dataIDAT, sizeIDAT))
	{
	case Z_OK:
		break;
	case Z_MEM_ERROR:
		error->code = ERROR_OUT_OF_MEMORY;
		error->message = "Memory error in uncompress";
		break;
	case Z_BUF_ERROR:
		error->code = ERROR_DATA_INVALID;
		error->message = "Buffer error in uncompress";
		break;
	case Z_DATA_ERROR:
		error->code = ERROR_DATA_INVALID;
		error->message = "DATA error in uncompress";
		break;
	default:
		error->code = ERROR_UNKNOWN;
		error->message = "Unknown error in uncompress";
		break;
	}
	int indF = 0;
	int indD = 0;
	for (int i = 0; i < size; i++)
	{
		if (i % (pnm->width * pnm->streams + 1) == 0)
		{
			pnm->filter[indF++] = allData[i];
			continue;
		}
		pnm->data[indD++] = allData[i];
	}
	free(allData);
}

void decompressPLTE(PNM *pnm, const byte *dataPLTE, ERROR *error)
{
	ulong size = pnm->height * pnm->width * 3;
	ulong sizeIndex = pnm->height * pnm->width;
	byte *indexData = (byte *)malloc(sizeIndex * sizeof(byte));
	if (indexData == NULL)
	{
		error->code = ERROR_DATA_INVALID;
		error->message = "Cannot get size for array indexData in decompressPLTE";
		return;
	}
	for (int i = 0; i < sizeIndex; i++)
	{
		indexData[i] = pnm->data[i];
	}
	pnm->data = (byte *)realloc(pnm->data, size);
	if (pnm->data == NULL)
	{
		error->code = ERROR_DATA_INVALID;
		error->message = "Cannot add size for array data in PNM in decompressPLTE";
		return;
	}
	for (int i = 0; i < sizeIndex; i++)
	{
		pnm->data[i * 3] = dataPLTE[indexData[i] * 3];
		pnm->data[i * 3 + 1] = dataPLTE[indexData[i] * 3 + 1];
		pnm->data[i * 3 + 2] = dataPLTE[indexData[i] * 3 + 2];
	}
	pnm->streams = 3;
	free(indexData);
}

int isChunk(const byte *word, const char *name)
{
	return name[0] == word[0] && name[1] == word[1] && name[2] == word[2] && name[3] == word[3];
}

void filter(PNM *pnm, ERROR *error)
{
	for (int i = 0; i < pnm->height; i++)
	{
		switch (pnm->filter[i])
		{
		case 0:
			break;
		case 1:
			filterSub(pnm, i);
			break;
		case 2:
			filterUp(pnm, i);
			break;
		case 3:
			filterAverage(pnm, i);
			break;
		case 4:
			filterPaeth(pnm, i);
			break;
		default:
			error->code = ERROR_DATA_INVALID;
			error->message = "Unknown filter type";
			return;
		}
	}
}

void filterSub(PNM *pnm, ulong start)
{
	for (size_t i = pnm->streams + start * pnm->width * pnm->streams; i < (start + 1) * pnm->width * pnm->streams; i++)
	{
		pnm->data[i] += pnm->data[i - pnm->streams];
	}
}

void filterUp(PNM *pnm, ulong start)
{
	for (size_t i = start * pnm->width * pnm->streams; i < (start + 1) * pnm->width * pnm->streams; i++)
	{
		pnm->data[i] += pnm->data[i - pnm->width * pnm->streams];
	}
}

void filterAverage(PNM *pnm, ulong start)
{
	for (size_t i = start * pnm->width * pnm->streams; i < start * pnm->width * pnm->streams + pnm->streams; i++)
	{
		pnm->data[i] += pnm->data[i - pnm->width * pnm->streams] / 2;
	}

	for (size_t i = pnm->streams + start * pnm->width * pnm->streams; i < (start + 1) * pnm->width * pnm->streams; i++)
	{
		pnm->data[i] += (pnm->data[i - pnm->streams] + pnm->data[i - pnm->width * pnm->streams]) / 2;
	}
}

void filterPaeth(PNM *pnm, ulong start)
{
	for (size_t i = start * pnm->width * pnm->streams; i < start * pnm->width * pnm->streams + pnm->streams; i++)
	{
		pnm->data[i] += pnm->data[i - pnm->width * pnm->streams];
	}

	for (size_t i = pnm->streams + start * pnm->width * pnm->streams; i < (start + 1) * pnm->width * pnm->streams; i++)
	{
		byte a = pnm->data[i - pnm->streams];
		byte b = pnm->data[i - pnm->width * pnm->streams];
		byte c = pnm->data[i - pnm->width * pnm->streams - pnm->streams];
		byte p = a + b - c;
		byte pa = abs(p - a);
		byte pb = abs(p - b);
		byte pc = abs(p - c);
		if (pa <= pb && pa <= pc)
		{
			pnm->data[i] += a;
		}
		else if (pb <= pc)
		{
			pnm->data[i] += b;
		}
		else
		{
			pnm->data[i] += c;
		}
	}
}