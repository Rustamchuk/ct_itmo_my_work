package markup;

public class Text {
    private final String text;
    public Text(String txt) { text = txt; }

    public String getText() { return text; }
}
