package game;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public enum Result {
    WIN, LOSE, DRAW, UNKNOWN
}
